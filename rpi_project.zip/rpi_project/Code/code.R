library(readr) # for reading the necessary datasets
library(ggplot2) # for plotting
library(tidyverse) # for data manipulation functions and ggplot
library(ggpubr) # for arranging plots into panels




# To explain quickly: R has been used pure for plotting the figures in a more proffessional way :);
# The main analyses has been made using data and the original plots generated on Microsoft Excel 
# (See Supplementary Table S1);
# For this R code, four separate .csv data sets have been created for each of the scatter plots; They 
# contain the measurements of the dimentions + the assigned instar for each specimen, drawing from the
# S1 tables; (One quick note: In the .csv data sets, Instars have been named a, b, c, d instead of numbers; 
# This makes the plotting easier; For the legend of Figure 2 as it is in the report, they were subsequently
# renamed using roman numbers using Inkscape, https://inkscape.org/)



#PL against PW plot
PLtoPW <- read_csv("Data/PLtoPW.csv") #read the file; Make sure you put in the right directory
PLtoPW

# Plotting the specimens, grouped in their respective instars
PLtoPW_plot <- ggplot(PLtoPW, aes(x=PW, y=PL, group=Growth_Stage)) +
  geom_point(aes(shape=Growth_Stage), size=2)+
  scale_shape_manual(values=c(1, 2, 3, 11, 4, 6, 7, 8))+ # Here we assign each instar its respective shape on the plot
  theme(legend.position="top") # determens the position of the legend, not too relevant for our purposes
PLtoPW_plot


#OL agains OW plot; The code will be basically the same as for the PL against PW plot, SO SEE COMMENTS THERE!
OLtoOW <- read_csv("Data/OLtoOW.csv")
OLtoOW

OLtoOW_plot <- ggplot(OLtoOW, aes(x=OW, y=OL, group=Growth_Stage)) +
  geom_point(aes(shape=Growth_Stage), size=2)+
  scale_shape_manual(values=c(1, 2, 3, 11, 17, 4, 19, 6, 7))+
  theme(legend.position="top")
OLtoOW_plot


# PW again OW Plot; The code will be basically the same as for the PL against PW plot, SO SEE COMMENTS THERE!
PWtoOW <- read_csv("Data/PWtoOW.csv")
PWtoOW

PWtoOW_plot <- ggplot(PWtoOW, aes(x=OW, y=PW, group=Growth_Stage)) +
  geom_point(aes(shape=Growth_Stage), size=2)+
  scale_shape_manual(values=c(1, 2, 3, 4, 6, 7, 8))+
  theme(legend.position="top")
PWtoOW_plot


#PL agains OL plot; The code will be basically the same as for the PL against PW plot, SO SEE COMMENTS THERE!
PLtoOL <- read_csv("Data/PLtoOL.csv")
PLtoOL

PLtoOL_plot <- ggplot(PLtoOL, aes(x=OL, y=PL, group=Growth_Stage)) +
  geom_point(aes(shape=Growth_Stage), size=2)+
  scale_shape_manual(values=c(1, 2, 3, 11, 4, 6, 7, 8))+
  theme(legend.position="top")
PLtoOL_plot



# Aranging them for a figure; We will make to two panel with two of the plots each (If we try to make
# one big panel with all four plots, thely will be too squashed :D Hence, we will just stitch the two pair 
# together in inkscape); After creating each panel, export it as a PDF, so you can process them later using 
# inkscape and combine them

panel <- ggarrange(PLtoPW_plot, OLtoOW_plot, # First pair; comment them after running the code, so you can do the othe rpair
                               
                   #PWtoOW_plot, PLtoOL_plot, # Second pair; uncomment and rerun code after first pair is done
                               
                   ncol = 2, nrow = 1) # no. of rows and columns
panel
################################################################################
citation()
version$version.string


